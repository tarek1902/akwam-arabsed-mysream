"""Provider adapters implement headers, categories, items, episodes, details, and link resolvers.

Each adapter exports get_headers, get_categories, get_items_list,
get_series_episodes, get_movie_details, get_video_stream_url, and
get_direct_file_url. Return the normalized item dictionaries consumed by ui.py.
"""
